-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 10-Dez-2017 às 18:07
-- Versão do servidor: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nome_usuario` varchar(255) CHARACTER SET latin1 NOT NULL,
  `nome_completo` varchar(255) NOT NULL,
  `email` varchar(255) CHARACTER SET latin1 NOT NULL,
  `data_nascimento` varchar(255) CHARACTER SET latin1 NOT NULL,
  `cidade` varchar(255) CHARACTER SET latin1 NOT NULL,
  `senha` varchar(255) CHARACTER SET latin1 NOT NULL,
  `datahora` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`id`, `nome_usuario`, `nome_completo`, `email`, `data_nascimento`, `cidade`, `senha`, `datahora`) VALUES
(5, 'João Ferreira', 'João Paulo de Araújo Ferreira', 'joaopauloaferreira23@gmail.com', '23/03/1998', 'Fortaleza', 'a6ffa251e23f6335ec157be08032cc99', '03/12/2017 14:13:56'),
(25, 'Alice', 'Alice Falcão', 'alicefalcao@gmail.com', '12/09/1998', 'Fortaleza', '1140d21b45fd4784d61cfccfe733adab', '10/12/2017 16:48:13'),
(28, 'mais um teste', 'Nara Lívia', 'joaopauloaferreira23@gmail.com', '30/11/2014', 'Fortaleza', 'dccd96c256bc7dd39bae41a405f25e43', '10/12/2017 17:18:09'),
(31, 'ronaldo o fenomeno', 'Ronaldo Nazario dos Santos', 'ronaldo@fenomeno.com', '30/10/2012', 'Rio de Janeiro', '202cb962ac59075b964b07152d234b70', '10/12/2017 17:42:57');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
